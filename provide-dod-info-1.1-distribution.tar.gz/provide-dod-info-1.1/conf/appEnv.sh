# File to be sourced in to application runner
# Allow for customisations here (allows application runner to be effectively read-only)

MAIN_CLASS=dk.kb.provide_dod_info.AlmaExtract


#Optional parameter to override default JAVA_OPTS
JAVA_OPTS="-Xmx512m"

